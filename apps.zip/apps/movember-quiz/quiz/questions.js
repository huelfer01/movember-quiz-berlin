/* Edit questions here. `answer` is the zero-based index of the correct option.
   Health guidance and statistics checked 9 November 2026.
   Age recommendations and statistics explicitly refer to Germany. */
window.QUIZ_QUESTIONS = [
  {
    topic: 'Prostate health · Germany',
    question: 'From what age do German guidelines recommend discussing PSA-based prostate cancer screening for men at average risk?',
    options: ['40 years', '45 years', '50 years', '55 years'],
    answer: 1,
    explanation: 'Discuss benefits and harms from 45; some inherited risks warrant starting earlier. Screening is a personal decision. Get symptoms checked at any age.',
    source: 'https://www.krebsinformationsdienst.de/prostatakrebs/frueherkennung',
    sourceLabel: 'DKFZ: prostate cancer screening (German)'
  },
  {
    topic: 'Understand the test',
    question: 'A PSA blood test comes back elevated. What does that result tell you?',
    options: [
      'It confirms prostate cancer, but not its stage',
      'It identifies how quickly a prostate tumour is growing',
      'It rules out a benign enlargement of the prostate',
      'It needs assessment; benign conditions can also raise PSA'
    ],
    answer: 3,
    explanation: 'Benign enlargement, inflammation and infection can raise PSA too. An elevated result is not a diagnosis; a doctor decides whether to repeat the test or investigate.',
    source: 'https://movember.com/articles/about-prostate-cancer',
    sourceLabel: 'Movember: PSA and prostate cancer'
  },
  {
    topic: 'Testicular health · Germany',
    question: 'In which age range do most testicular cancer cases occur in Germany?',
    options: ['25–45 years', '45–65 years', '65–85 years', '5–25 years'],
    answer: 0,
    explanation: 'Most cases occur between 25 and 45, according to the Robert Koch Institute. It can occur at other ages too. Get familiar with your normal.',
    source: 'https://edoc.rki.de/bitstream/handle/176904/13155/krebs_in_deutschland_2025.pdf',
    sourceLabel: 'RKI: Cancer in Germany, testicular cancer chapter (German PDF)'
  },
  {
    topic: 'Notice a change',
    question: 'You find a new lump in a testicle, but it does not hurt. What is the best next step?',
    options: [
      'Monitor it for a month before booking',
      'Mention it at your next annual check-up',
      'Book a medical appointment promptly, even without pain',
      'Book if it becomes painful or grows'
    ],
    answer: 2,
    explanation: 'Testicular cancer can cause painless lumps or swelling. Get new changes checked promptly; do not wait for pain. Many changes have other causes.',
    source: 'https://www.krebsinformationsdienst.de/hodenkrebs',
    sourceLabel: 'DKFZ: testicular cancer symptoms (German)'
  },
  {
    topic: 'Mental health · Germany, 2025',
    question: 'Approximately what share of people who died by suicide in Germany in 2025 were men?',
    options: ['About 50%', 'About 60%', 'About 70%', 'About 80%'],
    answer: 2,
    explanation: 'Destatis reports 69.2% for Germany in 2025. This measures deaths, not attempts. Reaching out and helping someone find support can matter.',
    source: 'https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Gesundheit/Todesursachen/Tabellen/suizide.html',
    sourceLabel: 'Destatis: suicide deaths, Germany 2025 (German)'
  },
  {
    topic: 'Ask · Start the conversation',
    question: 'A colleague has become unusually withdrawn. What is the best way to start a conversation?',
    options: [
      'Ask privately: “You seem quieter lately. How are you doing?”',
      'Ask at lunch so the team can offer support',
      'Offer stress-management tips before asking how they feel',
      'Wait until they raise it in their own time'
    ],
    answer: 0,
    explanation: 'Choose a private, unhurried moment and mention what you have noticed. If they say they are fine but you remain concerned, ask again with care.',
    source: 'https://us.movember.com/mens-health/give-support',
    sourceLabel: 'Movember: Ask, Listen, Encourage action, Check in'
  },
  {
    topic: 'Listen · Make room',
    question: 'A friend says, “I am not coping.” Which response best shows that you are listening?',
    options: [
      '“I have been there. Here is what helped me.”',
      '“Let us make a plan to solve this.”',
      '“You have got through tough times before. You can again.”',
      '“That sounds really difficult. Do you want to tell me more?”'
    ],
    answer: 3,
    explanation: 'Acknowledge how they feel and invite them to talk. Listen without judging. Advice and reassurance can wait; first, make space for their experience.',
    source: 'https://us.movember.com/mens-health/give-support',
    sourceLabel: 'Movember: listening and supporting a friend'
  },
  {
    topic: 'Encourage action · Find support',
    question: 'A friend has felt low for weeks and struggles day to day. What is the most helpful next step?',
    options: [
      'Try exercise and sleep changes before outside help',
      'Encourage professional support; offer help arranging it',
      'Keep talking and reassess in a few weeks',
      'Leave them to decide if they need help'
    ],
    answer: 1,
    explanation: 'Suggest a doctor or mental health professional and offer practical help. Healthy habits support care, but cannot replace it. Seek support sooner if needed.',
    source: 'https://us.movember.com/mens-health/give-support',
    sourceLabel: 'Movember: encouraging action and professional support'
  },
  {
    topic: 'Ask directly · Suicide prevention',
    question: 'You worry a friend is thinking about suicide. Which approach is recommended?',
    options: [
      'Ask about stress; let them introduce suicide',
      'Reassure them they have reasons to keep going',
      'Ask calmly and directly about suicidal thoughts',
      'Arrange another conversation when their mood improves'
    ],
    answer: 2,
    explanation: 'Asking directly does not increase suicidal thoughts. Listen and help them connect with support. In immediate danger, stay with them and contact emergency services.',
    source: 'https://www.who.int/news-room/questions-and-answers/item/suicide',
    sourceLabel: 'WHO: talking about suicide and helping someone'
  },
  {
    topic: 'Check in · Keep showing up',
    question: 'After a friend opens up, what best puts Movember’s “Check in” step into practice?',
    options: [
      'Agree when to reconnect, then follow through',
      'Give them space; wait for them to contact you',
      'Leave follow-up to their doctor after an appointment',
      'Share the details so mutual friends can monitor them'
    ],
    answer: 0,
    explanation: 'Follow up as agreed. Ask how they are and how next steps went. ALEC means Ask, Listen, Encourage action, Check in; support continues beyond one conversation.',
    source: 'https://conversations.movember.com/en/ALEC/check%20In/',
    sourceLabel: 'Movember Conversations: Check in'
  }
];
