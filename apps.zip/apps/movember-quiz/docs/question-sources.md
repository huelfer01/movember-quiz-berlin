## Branding and question sources

The quiz and printable QR poster use the original Oliver Wyman SVG logo extracted from `01 Input/MovemberTemplate.pptx`. Its proportions are preserved. Theme colours come from that deck: navy `#000F47`, blue `#82BAFF`, light blue `#CEECFF`, and warm grey `#EBE7E2`. The typography uses Marsh Serif and Noto Sans when installed, with local Georgia/Arial fallbacks; no remote fonts or proprietary font files are distributed.

There are ten questions, each with four plausible choices and a brief explanation:

1. Age to discuss PSA-based prostate screening in Germany: **45** for average risk. This asks about informed discussion, rather than mandatory testing. Specific inherited risks may justify starting earlier; symptoms need assessment at any age.
2. An elevated PSA result: **needs assessment and is not a cancer diagnosis**.
3. The age range in which most testicular cancer cases occur in Germany: **25–45**. Cases also occur outside that range.
4. A new painless testicular lump: **arrange a medical check promptly**.
5. The male share of suicide deaths in Germany in 2025: **69.2%**, so “about 70%”. This is deaths, not attempts, and is not a global percentage.
6. Start a private conversation about a change you have noticed.
7. Listen and acknowledge before offering solutions.
8. Encourage professional help for persistent distress and offer practical support.
9. Ask directly about suicidal thoughts when concerned; this does not increase suicidal thoughts. In immediate danger, stay with the person and contact emergency services.
10. Agree a follow-up and keep that commitment.

Sources checked 9 November 2026; each explanation contains a direct link:

- [DKFZ: PSA-based prostate screening](https://www.krebsinformationsdienst.de/prostatakrebs/frueherkennung)
- [Movember: prostate cancer and PSA](https://movember.com/articles/about-prostate-cancer)
- [RKI: Cancer in Germany 2021–2023, testicular cancer chapter](https://edoc.rki.de/bitstream/handle/176904/13155/krebs_in_deutschland_2025.pdf)
- [DKFZ: testicular cancer and symptoms](https://www.krebsinformationsdienst.de/hodenkrebs)
- [Destatis: suicide deaths in Germany, 2025](https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Gesundheit/Todesursachen/Tabellen/suizide.html)
- [Movember: ALEC and supporting someone](https://us.movember.com/mens-health/give-support)
- [WHO: talking about suicide and helping someone](https://www.who.int/news-room/questions-and-answers/item/suicide)
- [Movember Conversations: Check in](https://conversations.movember.com/en/ALEC/check%20In/)

The original handouts informed the topics. German guidance and dated national statistics replace the handouts' older numerical claims. This is why the age ranges may differ from a generic Movember poster. All question wording is newly written.

